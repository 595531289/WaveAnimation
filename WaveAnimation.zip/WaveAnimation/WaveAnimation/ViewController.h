//
//  ViewController.h
//  WaveAnimation
//
//  Created by 王斌 on 2019/7/13.
//  Copyright © 2019 wangbin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

